var sessionId;
var sessionDataObject;
var html = '';

function initForm() {
    if (sessionStorage.length > 0) {
        sessionDataObject = JSON.parse(sessionStorage.sessionId);
        sessionId = sessionDataObject.id;
    }
    ;

    if (sessionId === null) {
        window.location = "index.html";
    }

    if (sessionId !== null) {
        loadLoggedInUser();
        loadDonationsCount();
        loadDonorsCount();
        loadOrdersCount();
        loadBloodCount();
    }
    ;
}

function loadDonationsCount() {
    // /getAllDonorBloods/{session}
    var url = '/service/getAllDonorBloods/' + sessionId;
    console.log(url);
    $.ajax({
        type: "POST",
        url: url,
        data: param = "",
        dataType: 'json',
        success: function (data, status) {
            $('#donationsCountId').html(data.length);
        },
        error: function (data, status) {
            
        }
    });
}

function loadDonorsCount() {
    // /getAllDonors/{session}
    var url = '/service/getAllDonors/' + sessionId;
    console.log(url);
    $.ajax({
        type: "POST",
        url: url,
        data: param = "",
        dataType: 'json',
        success: function (data, status) {
            $('#donorsCountId').html(data.length);
        },
        error: function (data, status) {
            
        }
    });
}

function loadOrdersCount() {
    // /getAllBloodOrders/{session}
    var url = '/service/getAllBloodOrders/' + sessionId;
    console.log(url);
    $.ajax({
        type: "POST",
        url: url,
        data: param = "",
        dataType: 'json',
        success: function (data, status) {
            $('#ordersCountId').html(data.length);
        },
        error: function (data, status) {
            
        }
    });
}

function loadBloodCount() {
    // /getAllBloods/{session}
    var url = '/service/getAllBloods/' + sessionId;
    console.log(url);
    $.ajax({
        type: "POST",
        url: url,
        data: param = "",
        dataType: 'json',
        success: function (data, status) {
            $('#bloodCountId').html(data.length);
        },
        error: function (data, status) {
            
        }
    });
}