
function initLogin() {

}

function setCookie(cname, cvalue) {
    sessionStorage.setItem(cname, cvalue);
}
function getCookie(cname) {
    return sessionStorage.getItem(cname);
}

function getQueryParameter(parameterName) {
    var queryString = window.top.location.search.substring(1);
    var parameterName = parameterName + "=";
    if (queryString.length > 0) {
        begin = queryString.indexOf(parameterName);
        if (begin != -1) {
            begin += parameterName.length;
            end = queryString.indexOf("&", begin);
            if (end == -1) {
                end = queryString.length
            }
            return unescape(queryString.substring(begin, end));
        }
    }
    return null;
}


function sendLogin() {
    var username = document.getElementById("username").value;
    var password = document.getElementById("password").value;
    
    if (username == '' || password == '') {
        $.notify({
            title: '<strong>Error!</strong>',
            message: 'Make sure you have provided both the username & password!'
        },{
            type: 'danger'
        });

    }else{
        $.ajax({
            type: "POST",
            url: "/service/login/" + username + '/' + password,
            data: param = "",
            dataType: 'json',
            success: function (data, status) {
                console.log(data);
                
                setCookie("sessionId", data);
                sessionStorage.setItem("sessionId", JSON.stringify(data));
                var mog = JSON.parse(sessionStorage.sessionId);
                console.log(mog.id);

                window.location = "dashboard.html";
                
            ;
            },
            error: function () {
                $.notify({
                    title: '<strong>Login Failed!</strong>',
                    message: 'Please make sure your password & username are correct!'
                }, {
                    type: 'danger'
                });
            }
        });
    }
}
