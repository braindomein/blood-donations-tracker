var sessionId;
var sessionDataObject;
var html = '';

function initForm() {
    if (sessionStorage.length > 0) {
        sessionDataObject = JSON.parse(sessionStorage.sessionId);
        sessionId = sessionDataObject.id;
    }
    ;

    if (sessionId === null) {
        window.location = "index.html";
    }

    if (sessionId !== null) {
        loadLoggedInUser();
        loadRecords();
        loadEmployees();
    }
    ;
}

function getQueryParameter(parameterName) {
    var queryString = window.top.location.search.substring(1);
    var parameterName = parameterName + "=";
    if (queryString.length > 0) {
        begin = queryString.indexOf(parameterName);
        if (begin !== -1) {
            begin += parameterName.length;
            end = queryString.indexOf("&", begin);
            if (end === -1) {
                end = queryString.length
            }
            return unescape(queryString.substring(begin, end));
        }
    }
    return null;
}

function loadEmployees() {
    // /getAllHospitals/{session}
    var url = '/service/getAllHospitals/' + sessionId;
    var html = '';
    $.ajax({
        type: "POST",
        url: url,
        data: param = "",
        dataType: 'json',
        success: function (data, status) {
            html += '<option disabled="" selected="">- Select Hospital -</option>';
            $.each(data, function (index, item) {
                html += '<option value="' + unescape(item.id) + '">' + unescape(item.name) + '</option>';
            });
            $('#hospital').html(html);
        },
        error: function (data, status) {
            if (data.status === 400) {
                $.notify({
                    title: '<strong>ERROR:</strong>',
                    message: 'Unable to load the record list'
                }, {
                    type: 'danger'
                });
            } else {
                $.notify({
                    title: '<strong>ERROR:</strong>',
                    message: 'Unable to load the record list'
                }, {
                    type: 'danger'
                });
            }
        }
    });
}

function loadRecords() {
    // /getAllBloodOrders/{session}
    var url = '/service/getAllBloodOrders/' + sessionId;
    console.log(url);
    $.ajax({
        type: "POST",
        url: url,
        data: param = "",
        dataType: 'json',
        success: function (data, status) {
            $.each(data, function (index, item) {
                console.log(data);
                html += '<tr>';
                html += '   <td>' + unescape(item.id) + '</td>';
                html += '   <td>' + unescape(item.criticalLevel) + '</td>';
                html += '   <td>' + unescape(item.hospital.name) + '</td>';
                html += '   <td>' + unescape(item.dateOfRequest) + '</td>';
                html += '   <td>' + unescape(item.comments) + '</td>';
                html += '   <td>' + unescape(item.dateSent) + '</td>';
                if (item.sent === true) {
                    html += '   <td>Y</td>';
                } else if (item.sent === false) {
                    html += '   <td>N</td>';
                }
                html += '   <td class="td-actions">';
                html += '       <a href="#myModal" role="button" class="btn btn-small btn-info" data-toggle="modal"><i class="btn-icon-only icon-edit"> </i></a>';
                html += '       <a href="#myDeleteModal" role="button" class="btn btn-small btn-danger" data-toggle="modal"><i class="btn-icon-only icon-remove"> </i></a>';
                html += '   </td>';
                html += '</tr>';
            });
            $('#recordsListHolderId').html(html);
        },
        error: function (data, status) {
            if (data.status === 400) {
                $.notify({
                    title: '<strong>ERROR:</strong>',
                    message: 'Unable to load the record list'
                }, {
                    type: 'danger'
                });
            } else {
                $.notify({
                    title: '<strong>ERROR:</strong>',
                    message: 'Unable to load the record list'
                }, {
                    type: 'danger'
                });
            }
        }
    });
}

function addRecordFunction() {
    var hospital = document.getElementById("hospital").value;
    var criticalLevel = document.getElementById("criticalLevel").value;
    var sent = document.getElementById("sent").value;
    var comments = document.getElementById("comments").value;
    var dateOfRequest = document.getElementById("dateOfRequest").value;
    var dateSent = document.getElementById("dateSent").value;

    var encodeHospital = encodeURIComponent(hospital);
    var encodeCriticalLevel = encodeURIComponent(criticalLevel);
    var encodeSent = encodeURIComponent(sent);
    var encodeDateOfRequest = encodeURIComponent(dateOfRequest);
    var encodeComments = encodeURIComponent(comments);
    var encodeDateSent = encodeURIComponent(dateSent);


    if (encodeHospital === '' || encodeCriticalLevel === '' || encodeSent === '' || encodeDateOfRequest === ''
            || encodeComments === '' || encodeDateSent === '') {
        $.notify({
            title: '<strong>Error:</strong>',
            message: 'Make sure you have provided the fields in the form!'
        }, {
            type: 'danger'
        });


    } else
        // /addBloodOrder/{session}/{hospitalId}/{criticalLevel}/{sent}/{comments}/{dateOfRequest}/{dateSent}
        var url = '/service/addBloodOrder/' + sessionId + '/' + encodeHospital + '/' + encodeCriticalLevel + '/' + encodeSent + '/'
                + encodeComments + '/' + encodeDateOfRequest + '/' + encodeDateSent;
    console.log(url);
    $.ajax({
        type: "POST",
        url: url,
        data: param = "",
        dataType: 'json',
        success: function (data, status) {
            $.notify({
                title: '<strong>SUCCESS:</strong>',
                message: 'Record  was added to the database '
            }, {
                type: 'success'
            });
            window.location = "manageBloodOrder.html";
        },
        error: function (data, status) {
            $.notify({
                title: '<strong>ERROR:</strong>',
                message: 'Record  was not added to the database '
            }, {
                type: 'danger'
            });

            console.log(data);
        }
    });
}
















var venueId = '';
function setDeletedVenueId(venue) {
    venueId = venue;
}
function deleteVenue() {
    // /deleteMake/{session}/{id}
    var url = '/service/deleteMake/' + sessionId + '/' + venueId;
    $.ajax({
        type: "POST",
        url: url,
        data: param = "",
        dataType: 'json',
        contentType: "application/json",
        success: function (data, status) {
            $.notify({
                title: '<strong>SUCCESS:</strong>',
                message: 'Venue deleted successful.'
            }, {
                type: 'success'
            });
            window.location = "all_makes.html";
        },
        error: function (data, status) {
            $.notify({
                title: '<strong>ERROR:</strong>',
                message: 'Venue cannot be deleted because its linked to a game.'
            }, {
                type: 'danger'
            });
        }
    });
}

var selectedItem = '';
function setSelectedItemId(itemId) {
    console.log("ItemId" + itemId);
    selectedItem = itemId;
    console.log("SelectedId" + selectedItem);
    loadSelectedItemInfo();
}

function loadSelectedItemInfo() {
    ///getMake/{session}/{id}
    var url = '/service/getMake/' + sessionId + '/' + selectedItem;
    var html = '';
    $.ajax({
        type: "POST",
        url: url,
        data: param = "",
        dataType: 'json',
        success: function (data, status) {
            console.log(data);
            html += '       <div';
            html += '           <label>';
            html += '               Name <span class="required">*</span>';
            html += '           </label>';
            html += '           <input type="hidden" class="form-control" name="id" id="id" value="' + data.id + '" required="" />';
            html += '           <input type="text" class="form-control" name="name" id="name" value="' + data.name + '" required="" />';
            html += '       </div>';

            $('#editModalBody').html(html);
        },
        error: function (data, status) {
            if (data.status === 400) {
                $.notify({
                    title: '<strong>ERROR:</strong>',
                    message: 'Unable to load the team information'
                }, {
                    type: 'danger'
                });
            } else {
                $.notify({
                    title: '<strong>ERROR:</strong>',
                    message: 'Unable to load the team information'
                }, {
                    type: 'danger'
                });
            }
        }
    });
}

function updateFunction() {

    var id = document.getElementById("id").value;
    var name = document.getElementById("name").value;

    var encodeId = encodeURIComponent(id);
    var encodedName = encodeURIComponent(name);


    if (encodeId === '' || encodedName === '') {
        $.notify({
            title: '<strong>Error:</strong>',
            message: 'Make sure you have provided the fields in the form!'
        }, {
            type: 'danger'
        });


    } else
        // /updateMake/{session}/{id}/{name}
        var url = '/service/updateMake/'
                + sessionId + '/'
                + encodeId + '/'
                + encodedName;

    $.ajax({
        type: "POST",
        url: url,
        data: param = "",
        dataType: 'json',
        success: function (data, status) {
            $.notify({
                title: '<strong>SUCCESS:</strong>',
                message: 'Venue updated to the database '
            }, {
                type: 'success'
            });

            window.location = "all_makes.html";
        },
        error: function (data, status) {

            $.notify({
                title: '<strong>ERROR:</strong>',
                message: 'Venue was not updated.'
            }, {
                type: 'danger'
            });
        }
    });
}