var sessionId;
var sessionDataObject;
var html = '';

function initForm() {
    if (sessionStorage.length > 0) {
        sessionDataObject = JSON.parse(sessionStorage.sessionId);
        sessionId = sessionDataObject.id;
    }
    ;

    if (sessionId === null) {
        window.location = "index.html";
    }

    if (sessionId !== null) {
        loadLoggedInUser();
        loadRecords();
    }
    ;
}

function getQueryParameter(parameterName) {
    var queryString = window.top.location.search.substring(1);
    var parameterName = parameterName + "=";
    if (queryString.length > 0) {
        begin = queryString.indexOf(parameterName);
        if (begin !== -1) {
            begin += parameterName.length;
            end = queryString.indexOf("&", begin);
            if (end === -1) {
                end = queryString.length
            }
            return unescape(queryString.substring(begin, end));
        }
    }
    return null;
}

function loadRecords() {
    // /getAllHospitals/{session}
    var url = '/service/getAllHospitals/' + sessionId;
    console.log(url);
    $.ajax({
        type: "POST",
        url: url,
        data: param = "",
        dataType: 'json',
        success: function (data, status) {
            $.each(data, function (index, item) {
                console.log(data);
                html += '<tr>';
                html += '   <td>' + unescape(item.id) + '</td>';
                html += '   <td>' + unescape(item.name) + '</td>';
                html += '   <td>' + unescape(item.contact) + '</td>';
                html += '   <td>' + unescape(item.email) + '</td>';
                html += '   <td>' + unescape(item.contactPersonName) + '</td>';
                html += '   <td>' + unescape(item.contactPersonContact) + '</td>';
                html += '   <td class="td-actions">';
                html += '       <a href="#myModal" role="button" class="btn btn-small btn-info" data-toggle="modal"><i class="btn-icon-only icon-edit"> </i></a>';
                html += '       <a href="#myDeleteModal" role="button" class="btn btn-small btn-danger" data-toggle="modal"><i class="btn-icon-only icon-remove"> </i></a>';
                html += '   </td>';
                html += '</tr>';
            });
            $('#recordsListHolderId').html(html);
        },
        error: function (data, status) {
            if (data.status === 400) {
                $.notify({
                    title: '<strong>ERROR:</strong>',
                    message: 'Unable to load the record list'
                }, {
                    type: 'danger'
                });
            } else {
                $.notify({
                    title: '<strong>ERROR:</strong>',
                    message: 'Unable to load the record list'
                }, {
                    type: 'danger'
                });
            }
        }
    });
}

function addRecordFunction() {
    var name = document.getElementById("name").value;
    var contact = document.getElementById("contact").value;
    var address = document.getElementById("address").value;
    var email = document.getElementById("email").value;
    var location = document.getElementById("location").value;
    var contactPersonName = document.getElementById("contactPersonName").value;
    var contactPersonContact = document.getElementById("contactPersonContact").value;

    var encodeName = encodeURIComponent(name);
    var encodeContact = encodeURIComponent(contact);
    var encodeAddress = encodeURIComponent(address);
    var encodeEmail = encodeURIComponent(email);
    var encodeLocation = encodeURIComponent(location);
    var encodeContactPersonName = encodeURIComponent(contactPersonName);
    var encodeContactPersonContact = encodeURIComponent(contactPersonContact);


    if (encodeName === '' || encodeContact === '' || encodeAddress === '' || encodeEmail === ''
            || encodeLocation === '' || encodeContactPersonName === '' || encodeContactPersonContact === '') {
        $.notify({
            title: '<strong>Error:</strong>',
            message: 'Make sure you have provided the fields in the form!'
        }, {
            type: 'danger'
        });


    } else
        // /addHospital/{session}/{name}/{contact}/{address}/{email}/{location}/{contactPersonName}/{contactPersonContact}
        var url = '/service/addHospital/' + sessionId + '/' + encodeName + '/' + encodeContact + '/'
                + encodeAddress + '/' + encodeEmail + '/' + encodeLocation + '/' + encodeContactPersonName + '/' + encodeContactPersonContact;
    console.log(url);
    $.ajax({
        type: "POST",
        url: url,
        data: param = "",
        dataType: 'json',
        success: function (data, status) {
            $.notify({
                title: '<strong>SUCCESS:</strong>',
                message: 'Record  was added to the database '
            }, {
                type: 'success'
            });
            window.location = "manageHospital.html";
        },
        error: function (data, status) {
            $.notify({
                title: '<strong>ERROR:</strong>',
                message: 'Record  was not added to the database '
            }, {
                type: 'danger'
            });

            console.log(data);
        }
    });
}
















var venueId = '';
function setDeletedVenueId(venue) {
    venueId = venue;
}
function deleteVenue() {
    // /deleteMake/{session}/{id}
    var url = '/service/deleteMake/' + sessionId + '/' + venueId;
    $.ajax({
        type: "POST",
        url: url,
        data: param = "",
        dataType: 'json',
        contentType: "application/json",
        success: function (data, status) {
            $.notify({
                title: '<strong>SUCCESS:</strong>',
                message: 'Venue deleted successful.'
            }, {
                type: 'success'
            });
            window.location = "all_makes.html";
        },
        error: function (data, status) {
            $.notify({
                title: '<strong>ERROR:</strong>',
                message: 'Venue cannot be deleted because its linked to a game.'
            }, {
                type: 'danger'
            });
        }
    });
}

var selectedItem = '';
function setSelectedItemId(itemId) {
    console.log("ItemId" + itemId);
    selectedItem = itemId;
    console.log("SelectedId" + selectedItem);
    loadSelectedItemInfo();
}

function loadSelectedItemInfo() {
    ///getMake/{session}/{id}
    var url = '/service/getMake/' + sessionId + '/' + selectedItem;
    var html = '';
    $.ajax({
        type: "POST",
        url: url,
        data: param = "",
        dataType: 'json',
        success: function (data, status) {
            console.log(data);
            html += '       <div';
            html += '           <label>';
            html += '               Name <span class="required">*</span>';
            html += '           </label>';
            html += '           <input type="hidden" class="form-control" name="id" id="id" value="' + data.id + '" required="" />';
            html += '           <input type="text" class="form-control" name="name" id="name" value="' + data.name + '" required="" />';
            html += '       </div>';

            $('#editModalBody').html(html);
        },
        error: function (data, status) {
            if (data.status === 400) {
                $.notify({
                    title: '<strong>ERROR:</strong>',
                    message: 'Unable to load the team information'
                }, {
                    type: 'danger'
                });
            } else {
                $.notify({
                    title: '<strong>ERROR:</strong>',
                    message: 'Unable to load the team information'
                }, {
                    type: 'danger'
                });
            }
        }
    });
}

function updateFunction() {

    var id = document.getElementById("id").value;
    var name = document.getElementById("name").value;

    var encodeId = encodeURIComponent(id);
    var encodedName = encodeURIComponent(name);


    if (encodeId === '' || encodedName === '') {
        $.notify({
            title: '<strong>Error:</strong>',
            message: 'Make sure you have provided the fields in the form!'
        }, {
            type: 'danger'
        });


    } else
        // /updateMake/{session}/{id}/{name}
        var url = '/service/updateMake/'
                + sessionId + '/'
                + encodeId + '/'
                + encodedName;

    $.ajax({
        type: "POST",
        url: url,
        data: param = "",
        dataType: 'json',
        success: function (data, status) {
            $.notify({
                title: '<strong>SUCCESS:</strong>',
                message: 'Venue updated to the database '
            }, {
                type: 'success'
            });

            window.location = "all_makes.html";
        },
        error: function (data, status) {

            $.notify({
                title: '<strong>ERROR:</strong>',
                message: 'Venue was not updated.'
            }, {
                type: 'danger'
            });
        }
    });
}