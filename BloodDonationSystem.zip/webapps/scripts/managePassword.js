var sessionId;
var sessionDataObject;
var html = '';

function initForm() {
    if (sessionStorage.length > 0) {
        sessionDataObject = JSON.parse(sessionStorage.sessionId);
        sessionId = sessionDataObject.id;
    }
    ;

    if (sessionId === null) {
        window.location = "index.html";
    }

    if (sessionId !== null) {
        loadLoggedInUser();
    }
    ;
}

function getQueryParameter(parameterName) {
    var queryString = window.top.location.search.substring(1);
    var parameterName = parameterName + "=";
    if (queryString.length > 0) {
        begin = queryString.indexOf(parameterName);
        if (begin !== -1) {
            begin += parameterName.length;
            end = queryString.indexOf("&", begin);
            if (end === -1) {
                end = queryString.length
            }
            return unescape(queryString.substring(begin, end));
        }
    }
    return null;
}

function changePassword() {

    var opassword = document.getElementById("opassword").value;
    var npassword = document.getElementById("npassword").value;
    var cpassword = document.getElementById("cpassword").value;

    if (opassword === '' || npassword === '' || cpassword === '') {
        $.notify({
            title: '<strong>Error!</strong>',
            message: 'Make sure you have provided both the username & password!'
        }, {
            type: 'danger'
        });

    } else {
        $.ajax({
            type: "POST",
            url: "/service/changePassword/" + sessionId + '/' + opassword + '/' + npassword,
            data: param = "",
            dataType: 'json',
            success: function (data, status) {
                $.notify({
                    title: '<strong>SUCCESS:</strong>',
                    message: 'Password change successful.'
                }, {
                    type: 'success'
                });

//                window.location = "managePassword.html";

            },
            error: function () {
                $.notify({
                    title: '<strong>Login Failed!</strong>',
                    message: 'Failed to change password. Please try again!'
                }, {
                    type: 'danger'
                });
            }
        });
    }
}
